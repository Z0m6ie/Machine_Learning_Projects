

# CartPole\_DDQN

1. ​DDQN:

Simple Double Deep Q-Learning implementation on the catpole environment on OpenAI Gym

1. ​How to run:

Python main.py &lt;Number of Episodes&gt;

Suggest 1500 episodes, the model has not been tuned well and takes a while to coverge.

1. ​Results:





