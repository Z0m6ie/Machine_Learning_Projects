
# Deep Q-Learning Capstone Project

1. Dependancies to run
OpenAI gym (follow link for install instructions)
[OpenAI install Instructions:](https://github.com/openai/gym#installing-everything)
PIL
Numpy
Tensorflow
Keras
Pandas

2. ​How to run:
cd to file location
Python main.py &lt;Number of Episodes&gt;
Code defaults to 1500 episodes if no number provided.
